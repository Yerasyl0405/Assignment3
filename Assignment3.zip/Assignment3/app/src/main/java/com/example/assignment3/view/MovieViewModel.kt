package com.example.assignment3.view

import androidx.compose.runtime.State
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.assignment3.model.Movie
import com.example.assignment3.network.RetrofitInstance
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.assignment3.network.KinopoiskApi

class MovieViewModel(private val api: KinopoiskApi) : ViewModel() {
    private val _moviesByCollection = mutableStateOf<List<Movie>>(emptyList())
    val moviesByCollection: State<List<Movie>> = _moviesByCollection

    fun fetchMoviesByCollection(type: String) {
        viewModelScope.launch {
            val response = api.getMoviesByCollection(type = type)
            if (response.isSuccessful) {
                _moviesByCollection.value = response.body()?.items ?: emptyList()
            } else {
                // Handle error
            }
        }
    }
}
