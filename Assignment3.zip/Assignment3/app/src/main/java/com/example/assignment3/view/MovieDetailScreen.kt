@file:Suppress("NAME_SHADOWING")

package com.example.assignment3.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberImagePainter

import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavController
import com.example.assignment3.model.Movie


import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.res.painterResource
import androidx.navigation.compose.rememberNavController

@Composable
fun MoviesByCollectionScreen(viewModel: MovieViewModel, collectionType: String, navController: NavController) {
    LaunchedEffect(collectionType) {
        viewModel.fetchMoviesByCollection(collectionType)
    }

    val movies by viewModel.moviesByCollection


    LazyVerticalGrid(
        columns = GridCells.Fixed(2), // Set to 2 columns for two rows
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp), // Space between rows
        horizontalArrangement = Arrangement.spacedBy(8.dp) // Space between columns
    ) {
        items(movies) { movie ->
            MovieItem(movie = movie) {

            }
        }
    }
}


@Composable
fun MovieItem(movie: Movie, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(111.dp)
            .clickable { onClick() }
    ) {
        Card(
            modifier = Modifier
                .height(156.dp)
                .fillMaxWidth()) {
            Image(
                painter = rememberImagePainter(data = movie.posterUrl),
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            )
        }
        Text(
            text = movie.nameRu ?: movie.nameEn ?: "Unknown",
            style = TextStyle(fontSize = 12.sp, color = Color.Gray),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}




@Composable
fun MovieCollectionRow(title: String, viewModel: MovieViewModel, onSeeAllClick: () -> Unit) {
    LaunchedEffect(title) {
        viewModel.fetchMoviesByCollection(title)
    }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = title, style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold))
            Text(
                text = "See All",
                modifier = Modifier.clickable { onSeeAllClick() },
                color = Color.Blue // Change color to indicate it's clickable
            )
        }
        val movies by viewModel.moviesByCollection

        LazyRow(
            modifier = Modifier.padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp) // Space between items
        ) {
            items(movies) { movie ->
                MovieItem(movie = movie) { /* Handle item click */ }
            }
        }
    }
}